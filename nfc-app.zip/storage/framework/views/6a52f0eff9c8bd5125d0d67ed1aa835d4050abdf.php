<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-5 py-5">
        <h1>Equipe</h1>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.commercials')->html();
} elseif ($_instance->childHasBeenRendered('oVldExo')) {
    $componentId = $_instance->getRenderedChildComponentId('oVldExo');
    $componentTag = $_instance->getRenderedChildComponentTagName('oVldExo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oVldExo');
} else {
    $response = \Livewire\Livewire::mount('admin.commercials');
    $html = $response->html();
    $_instance->logRenderedChild('oVldExo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>

<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/admin/agents.blade.php ENDPATH**/ ?>