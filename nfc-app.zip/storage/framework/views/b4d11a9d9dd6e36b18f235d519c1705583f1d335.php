<?php $__env->startComponent('mail::message'); ?>
# Mail from Altechs NFC

This is a test mail from Altechd NFC app!

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Test link
<?php echo $__env->renderComponent(); ?>

Thanks, <br>
From ALTECHS NFC
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/mails/newsletter.blade.php ENDPATH**/ ?>