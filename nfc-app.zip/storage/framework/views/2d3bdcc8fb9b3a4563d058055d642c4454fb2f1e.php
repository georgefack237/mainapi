<div class="mt-3">
    <a href="#" class="btn btn-sm btn-success mb-3" wire:click="showCreate">Nouvau</a>
    <div class="bg-lighter py-3 px-3 mt-3 mb-4 rounded">
        <h2 class="h3 mb-3">Administrateurs</h2>
        <div class="row">
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="nfc-profile-item bg-secondary shadow-lg py-3 px-4 rounded">
                        <div class="media">
                            <div class="media-body d-flex align-content-center">
                                <a href="#" class="avatar rounded-circle mr-3">
                                    <img alt="Image placeholder" src="<?php echo e(asset('storage/img/nfc/profile/default.jpg')); ?>">
                                </a>
                                <div>
                                    <span class="name mb-0 text-sm font-weight-bold"><?php echo e($item->name); ?></span>
                                    <small class="name mb-0 text-sm text-muted d-block"><?php echo e($item->email); ?></small>
                                </div>
                                <div class="col-1 media align-items-center justify-content-center ml-4">
                                    
                                    <a href="#"
                                        class="fa fa-pen btn btn-info btn-sm rounded-pill mx-auto shadow-none"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <h2 class="h3 mb-3">Agents</h2>
    <div class="row">
        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="nfc-profile-item bg-secondary shadow-lg py-3 px-4 mb-3 rounded">
                    <div class="media">
                        <div class="media-body d-flex align-content-center">
                            <a href="#" class="avatar rounded-circle mr-3">
                                <img alt="Image placeholder" src="<?php echo e(asset('storage/img/nfc/profile/default.jpg')); ?>">
                            </a>
                            <div>
                                <span class="name mb-0 text-sm font-weight-bold"><?php echo e($item->name); ?></span>
                                <small class="name mb-0 text-sm text-muted d-block"><?php echo e($item->email); ?></small>
                            </div>
                            <div class="col-1 media align-items-center justify-content-center ml-4">
                                
                                <a href="#"
                                    class="fa fa-pen btn btn-info btn-sm rounded-pill mx-auto shadow-none"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Create profile modal -->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['maxWidth' => 'sm','wire:model' => 'createModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => 'sm','wire:model' => 'createModal']); ?>
         <?php $__env->slot('title', null, []); ?> 

         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <form>
                <div class="form-group">
                    
                    <label for="inputEmail4 text-sm">Nom</label>
                    <input type="text" class="form-control form-control-muted border-0" wire:model="name"
                        id="inputEmail4">
                </div>
                <div class="form-group">
                    <label for="inputEmail4 text-sm">Adresse mail</label>
                    <input type="text" class="form-control form-control-muted border-0" wire:model="email"
                        id="inputEmail4">
                </div>
                <div class="form-group">
                    <select class="custom-select form-control form-control-muted" wire:model="role">
                        <option selected>Role...</option>
                        <option value="Admin">Admin</option>
                        <option value="Agent">Agents</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="inputEmail4 text-sm">Mot de pass</label>
                    <input type="password" class="form-control form-control-muted border-0" wire:model="password"
                        id="inputEmail4">
                </div>

                <div class="d-flex align-item-center justify-content-center">
                    <div class="">
                        <button type="button" class="btn btn-success" wire:click="createItem"
                            wire:loading.attr="disabled">Enregistrer</button>
                        <button type="button" class="btn btn-outline-success" wire:click="$toggle('createModal')"
                            wire:loading.attr="disabled">Annuler</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, ['class' => 'd-none bg-white']); ?> 
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/livewire/commercials.blade.php ENDPATH**/ ?>