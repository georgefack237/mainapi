<div class="mt-3">
    
    <div class="row mb-3">
        <div class="col-lg-5 col-8">
            <div class="form-group position-relative d-block mb-0">
                <input wire:model="search" class="form-control form-control-sm form-control-muted bg-lighter"
                    placeholder="Recherche..." type="text"><i class="fas fa-search text-muted position-absolute" style="right: 10px;top:25%;"></i>
            </div>
        </div>
        <div class="col-lg-2 col-4 text-right">
            <div class="form-group">
                <select wire:model.lazy="perPage" class="form-control form-control-sm form-control-muted bg-lighter"
                    id="exampleFormControlSelect1">
                    <?php for($i = 5; $i <= 25; $i += 5): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?> par page</option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="col-lg-5 text-right d-none d-lg-block">
            <div class="mt-3 mt-lg-0 d-flex align-items-center border-left pl-4" role="group" aria-label="Basic example">
                <span class="text-sm mr-2">Filtrer par :</span>
                <button type="button" id="this-day" class="btn btn-sm btn-secondary badge-info font-weight-light shadow-none" onclick="thisDay()" wire:click='thisDay()'>
                    Stardard
                </button>
                <button type="button" id="this-week" class="btn btn-sm btn-secondary badge-warning font-weight-light shadow-none" onclick="thisWeek()" wire:click='thisWeek()'>
                    Entreprise
                </button>
                <button type="button" id="this-month" class="btn btn-sm btn-secondary badge-primary font-weight-light shadow-none" onclick="thisMonth()" wire:click='thisMonth()'>
                    Entreprise Plus
                </button>
                <a href="#" wire:click="showCreate" class="btn btn-sm btn-info ml-auto shadow-none"><i class="fa fa-plus mr-1"></i> Nouveau</a>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="nfc-profile-item bg-secondary py-2 px-3 mb-2 rounded">
            <div class="row">
                <div class="col-4 d-flex align-items-center">
                    <div class="media">
                        <div class="media-body d-flex align-content-center">
                            <div class="rounded-circle <?php echo e($item->package_id == 1 ? 'bg-info' : 'bg-primary'); ?> mr-3 my-auto" style="height: 8px; width: 8px;"></div>
                            <a href="#" class="avatar rounded-circle mr-3">
                                <img alt="Image placeholder" src="<?php echo e(asset('storage/img/nfc/profile/default.jpg')); ?>">
                            </a>
                            <div>
                                <span class="name mb-0 text-sm font-weight-bold"><?php echo e($item->name); ?></span>
                                <small class="name mb-0 text-xs text-muted d-block"><?php echo e($item->specialization); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3 align-items-center">
                    <span class="name mb-0 text-sm font-weight-bold"><?php echo e($item->website); ?></span>
                    <small class="name mb-0 text-xs text-muted d-block"><?php echo e($item->email); ?></small>
                </div>
                <div class="col-2 d-flex align-items-center">
                    <span class="mb-0 text-sm"><?php echo e($item->country); ?></span>
                    
                </div>
                <div class="col-2 media d-flex align-items-center">
                    <span class="mb-0 text-capitalize badge <?php echo e($item->package->color); ?> rounded"><?php echo e($item->package->name); ?></span>
                </div>
                <div class="col-1 media align-items-center justify-content-center border-left">
                    
                    <a href="<?php echo e(route('admin.client', $item->id)); ?>" class="btn btn-info btn-sm rounded mx-auto shadow-none"><i
                            class="fa fa-eye mr-1"></i>Voir</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="">
        <div class="col-md-6 ml-auto">
            <?php echo e($clients->links()); ?>

        </div>
    </div>

    <!-- Create profile modal -->

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['maxWidth' => 'sm','wire:model' => 'createModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => 'sm','wire:model' => 'createModal']); ?>
         <?php $__env->slot('title', null, []); ?> 

         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <form>
                <div class="form-group">
                    
                    <label for="inputEmail4">Nom</label>
                    <input type="text" class="form-control form-control-muted border-0" wire:model="name"
                        id="inputEmail4">
                </div>
                <div class="form-group">
                    <label for="inputPassword4">Adress mail</label>
                    <input type="text" class="form-control form-control-muted border-0" wire:model="email"
                        id="inputPassword4">
                </div>
                <div class="form-group">
                    <label for="inputPassword4">Siet web</label>
                    <input type="text" class="form-control form-control-muted border-0" wire:model="website"
                        id="inputPassword4">
                </div>
                <div class="form-group">
                    <label for="inputPassword4">Secteur d'activité</label>
                    <input type="text" class="form-control form-control-muted border-0" wire:model="specialization"
                        id="inputPassword4">
                </div>

                <div class="form-group">
                    <label for="inputEmail4">Pay</label>
                    <input type="text" class="form-control form-control-muted border-0" wire:model="country"
                        id="inputEmail4">
                </div>

                <div class="form-row">
                    <div class="form-group col-md-10">
                        <select class="custom-select form-control form-control-muted" wire:model="package">
                            <option selected>Package...</option>
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group col-md-2">
                        <input type="text" class="form-control form-control-muted border-0" placeholder="Limit" wire:model="createLimit"
                            id="inputEmail4">
                    </div>
                </div>

                <div class="d-flex align-item-center justify-content-center">
                    <div class="">
                        <button type="button" class="btn btn-success" wire:click="create"
                            wire:loading.attr="disabled">Enregistrer</button>
                        <button type="button" class="btn btn-outline-success" wire:click="$toggle('createModal')"
                            wire:loading.attr="disabled">Annuler</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, ['class' => 'd-none bg-white']); ?> 
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/livewire/clients.blade.php ENDPATH**/ ?>