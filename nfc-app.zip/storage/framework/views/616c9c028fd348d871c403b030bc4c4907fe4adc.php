<?php $__env->startSection('content'); ?>

    <div class="px-5 py-5">
        <h2>Partner Dashboard</h2>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/partner/dashboard/index.blade.php ENDPATH**/ ?>