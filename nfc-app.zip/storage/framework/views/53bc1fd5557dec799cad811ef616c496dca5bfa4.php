<?php $__env->startSection('content'); ?>

    <div class="px-5 py-5">
        <h2>Agent's Profile Dashboard</h2>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/profiles/dashboard/index.blade.php ENDPATH**/ ?>