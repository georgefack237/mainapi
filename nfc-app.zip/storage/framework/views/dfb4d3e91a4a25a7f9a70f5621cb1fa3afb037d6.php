<?php $__env->startSection('content'); ?>

    <div class="px-5 py-5">
        <h1>Clients</h1>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('partner.clients')->html();
} elseif ($_instance->childHasBeenRendered('5bHLY5l')) {
    $componentId = $_instance->getRenderedChildComponentId('5bHLY5l');
    $componentTag = $_instance->getRenderedChildComponentTagName('5bHLY5l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5bHLY5l');
} else {
    $response = \Livewire\Livewire::mount('partner.clients');
    $html = $response->html();
    $_instance->logRenderedChild('5bHLY5l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/partner/clients.blade.php ENDPATH**/ ?>