<div>
    <div class="header bg-white py-4">
        <div class="container-fluid">
            <div class="header-body">
                <div class="align-items-center mt-4 py-3">
                    <div class="d-flex justify-content-between">
                        <h2 class="mb-4 h1">Contacts</h2>
                    </div>
                    <div class="row justify-content-between align-items-center">
                        <div class="col-lg-4 form-group position-relative mb-0">
                            <input wire:model="search" class="form-control form-control-sm form-control-muted border-0"
                                placeholder="Recherche..." type="text"><i
                                class="fas fa-search text-primary position-absolute" style="right: 25px;top:25%;"></i>
                        </div>
                        <div class="col-lg-6 mt-3 mt-lg-0 d-flex justify-content-between justify-content-lg-end">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group mb-2">
                                        
                                        <input type="date" class="form-control form-control-muted form-control-sm border-0"
                                            wire:model="fromDate">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group mb-2">
                                        
                                        <input type="date" class="form-control form-control-muted form-control-sm border-0"
                                            wire:model="toDate">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bg-dander col-lg-2 text-right">
                            <div class="badge badge-lg badge-primary m-0"><?php echo e($contacts->count()); ?> contacts</div>
                        </div>
                    </div>
                    <form id="save-form" method="POST" action="<?php echo e(route('batchSave')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="date" value="<?php echo e($whereDate); ?>">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid mb-5 mt-3" style="border-radius: 20px;">
        <div class="nfc-profile-item py-1 px-3 my-2 rounded d-none d-lg-block">
            <div class="row">
                <div class="col-8 col-lg-4">
                    <div class="media align-items-center">
                        <div class="media-body">
                            <span class="name mb-0 font-weight-bold text-muted text-sm">Nom</span>
                        </div>
                    </div>
                </div>
                <div class="col-3 media align-items-center">
                    <span class="mb-0 font-weight-bold text-muted text-sm">Contact</span>
                </div>
                <div class="col-3 col-lg-2 media d-none d-lg-inline">
                    <small class="mb-0 font-weight-bold text-muted text-sm">Note</small>
                </div>
                <div class="col-1 col-lg-2 media d-none d-lg-inline">
                    <small class="mb-0 font-weight-bold text-muted text-sm">Source</small>
                </div>
                <div class="col-1 text-center border-left d-none d-lg-block">
                    <small class="mb-0 font-weight-bold text-muted text-sm mr-3"><i class="bi bi-toggles"></i></small>
                </div>
            </div>
        </div>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="py-2 px-3 mb-2 rounded bg-secondary">
                <div class="d-flex ali d-lg-block rounded">
                    <div class="row">
                        <div class="col-lg-4">
                            <a class="text-dark" href="#note-<?php echo e($item->id); ?>" data-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="note-<?php echo e($item->id); ?>">
                                <div class="media align-items-center">
                                    <div class="mr-3 my-auto">
                                        <?php if($item->has_cycle): ?>
                                            <span class="btn btn-sm badge-primary rounded-circle"><i
                                                    class="fa fa-user text-primary"></i></span>
                                        <?php else: ?>
                                            <span class="btn btn-sm badge-warning rounded-circle"><i
                                                    class="fa fa-user text-warning"></i></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm font-weight-bold"><?php echo e($item->name); ?></span>
                                        <small class="name mb-0 text-xs text-muted d-block"><?php echo e($item->title); ?></small>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3 align-items-center d-none d-lg-block">
                            <small class="mb-0 d-block font-weight-500 text-sm"><?php echo e($item->phone); ?></small>
                            <?php if($item->email): ?>
                                <small class="mb-0 d-block font-weight-600 text-xs"><i
                                        class="fa fa-envelope mr-2 text-primary"></i><?php echo e($item->email); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-2 media d-none d-lg-inline">
                            <?php if($item->note): ?>
                                <p class="mb-0 text" style="line-height: 1;"><small data-toggle="tooltip"
                                        data-placement="top"
                                        title="<?php echo e($item->note); ?>"><?php echo e(Str::limit($item->note, 40)); ?></small></p>
                            <?php else: ?>
                                <a href="#" class="btn btn-sm btn-outline-secondary rounded-pill shadow-none"
                                    wire:click='newNote(<?php echo e($item->id); ?>)'>
                                    <i class="fa fa-plus mr-2"></i>Ajouter une note</a>
                            <?php endif; ?>
                        </div>
                        <div class="col-2 media d-none d-lg-inline">
                            <?php if($item->is_manual): ?>
                                <small class="mb-0">Manuel</small>
                            <?php else: ?>
                                <small class="mb-0 text-xs">NFC/QR Code</small>
                            <?php endif; ?>
                        </div>
                        <div class="col-1 media align-items-center justify-content-center border-left">
                            <span class="dropdown">
                                <a class="btn btn-sm btn-icon-only text-primary shadow-none" href="#"
                                    role="button" data-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="fas fa-ellipsis-h"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                    <div class="px-3 py-2">
                                        <h6 class="text-xs text-muted m-0">Action</h6>
                                    </div>
                                    <a class="dropdown-item" href="tel:<?php echo e($item->phone); ?>">
                                        <i class="fa fa-phone text-primary mr-3"></i>Appeler</a>
                                    <a class="dropdown-item" href="mailto:<?php echo e($item->email); ?>">
                                        <i class="fa fa-paper-plane text-primary mr-3"></i>Envoyer un mail</a>
                                    <a class="dropdown-item" href="#"
                                        wire:click="newCycle(<?php echo e($item->id); ?>)"><i
                                            class="bi bi-bag-plus text-warning mr-3"></i>Nouveau cycle</a>
                                </div>
                            </span>
                        </div>
                    </div>
                    <div class="ml-auto my-auto">
                        <span class="btn btn-sm badge-success d-lg-none rounded-circle"><a
                                href="<?php echo e(route('phoneSave', $item->id)); ?>"
                                class="fa fa-arrow-down text-success"></a></span>
                    </div>
                </div>

                
                <div class="collapse mt-1" id="note-<?php echo e($item->id); ?>">
                    <div class="align-items-center d-inline d-lg-none text-sm ml-5">
                        <small class="mb-0 mr-2 font-weight-bold"><i
                                class="fa fa-phone mr-2 text-primary"></i><?php echo e($item->phone); ?></small>
                        <?php if($item->email): ?>
                            <small class="mb-0 font-weight-bold"><i
                                    class="fa fa-envelope mr-2 text-primary"></i><?php echo e($item->email); ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="text-sm ml-5 d-block d-lg-none">
                        <small class="">Agent en charge:</small>
                        <small class=""><?php echo e($item->nfcprofile->firstname); ?>

                            <?php echo e($item->nfcprofile->lastname); ?></small>
                    </div>
                    <?php if($item->lastNote): ?>
                        <div class="py-1 px-3 rounded bg-lighter mt-3 mb-2">
                            <div class="d-flex justify-content-between pb-1">
                                <div class="text-primary">
                                    <span class="text-xs font-weight-700">
                                        <i href="#" class="fa fa-message mr-2"></i>Note:</span>
                                </div>
                            </div>
                            <div class="mb-2 mt-2">
                                
                                <p class="text-xs"><?php echo e($item->lastNote); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['maxWidth' => 'sm','wire:model' => 'newNoteModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => 'sm','wire:model' => 'newNoteModal']); ?>
         <?php $__env->slot('title', null, []); ?> 
            Ajouter une note
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <form>
                <div class="form-group">
                    
                    <textarea class="form-control form-control-muted border-0" cols="10" rows="3" wire:model="note"
                        id="inputPassword4"></textarea>
                </div>

                <div class="d-flex align-item-center justify-content-center">
                    <div class="">
                        <button type="button" class="btn btn-primary" wire:click="addNote"
                            wire:loading.attr="disabled">Enregistrer</button>
                        <button type="button" class="btn btn-outline-primary" wire:click="$toggle('newNoteModal')"
                            wire:loading.attr="disabled">Annuler</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, ['class' => 'd-none bg-white']); ?> 
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['maxWidth' => 'sm','wire:model' => 'newCycleModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => 'sm','wire:model' => 'newCycleModal']); ?>
         <?php $__env->slot('title', null, []); ?> 
            Sélectionnez un produit
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <form>
                <div class="form-group">
                    <select class="custom-select form-control text-xs form-control-muted border-0"
                        wire:model="productId">
                        <option value="" selected>Tous les produits/services</option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="d-flex align-item-center justify-content-center">
                    <div class="">
                        <button type="button" class="btn btn-primary" wire:click="createCycle"
                            wire:loading.attr="disabled">Enregistrer</button>
                        <button type="button" class="btn btn-outline-primary" wire:click="$toggle('newCycleModal')"
                            wire:loading.attr="disabled">Annuler</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, ['class' => 'd-none bg-white']); ?> 
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['maxWidth' => 'sm','wire:model' => 'newContactModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => 'sm','wire:model' => 'newContactModal']); ?>
         <?php $__env->slot('title', null, []); ?> 
            Ajouter un contact
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <form>
                <div class="form-group col-12">
                    <input type="text" class="form-control form-control-muted border-0"
                        style="background: #edf0ff;" placeholder="Nom" wire:model="name">
                    <i class="fas fa-user text-primary position-absolute" style="right: 25px;top:30%;"></i>
                </div>
                <div class="form-group col-12">
                    <input type="text" class="form-control form-control-muted border-0"
                        style="background: #edf0ff;" placeholder="Fonction et Entreprise" wire:model="title">
                    <i class="fas fa-user-tie text-primary position-absolute" style="right: 25px;top:30%;"></i>
                </div>
                <div class="form-group col-12">
                    <input type="text" class="form-control form-control-muted border-0 position-relative"
                        style="background: #edf0ff;" placeholder="Adresse mail" wire:model="email">
                    <i class="fas fa-envelope text-primary position-absolute" style="right: 25px;top:30%;"></i>
                </div>
                <div class="form-group col-12 mb-3">
                    <input type="text" class="form-control form-control-muted border-0 position-relative"
                        style="background: #edf0ff;" placeholder="Téléphone" wire:model="phone">
                    <i class="fas fa-phone text-primary position-absolute" style="right: 25px;top:30%;"></i>
                </div>
                <div class="ml-3 mb-5">
                    <span class="mr-3 text-muted">Sex:</span>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" wire:model="gender" id="inlineRadio1"
                            value="Masculin">
                        <label class="form-check-label" for="inlineRadio1">Masculin</label>
                    </div>
                    <div class="form-check form-check-inline ">
                        <input class="form-check-input" type="radio" wire:model="gender" id="inlineRadio2"
                            value="Feminin">
                        <label class="form-check-label" for="inlineRadio2">Feminin</label>
                    </div>
                </div>

                <div class="d-flex align-item-center justify-content-center">
                    <div class="">
                        <button type="button" class="btn btn-primary" wire:click="addContact"
                            wire:loading.attr="disabled">Ajouter</button>
                        <button type="button" class="btn btn-outline-primary"
                            wire:click="$toggle('newContactModal')" wire:loading.attr="disabled">Annuler</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, ['class' => 'd-none bg-white']); ?> 
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    
    <a href="#" class="menu-btn text-white d-flex justify-content-center align-items-center"
        wire:click="$toggle('newContactModal')">
        <i class="fa fa-user-plus"></i>
    </a>

    <?php $__env->startPush('scripts'); ?>
        <script>
            function thisDay() {
                document.getElementById("this-week").classList.remove("active");
                document.getElementById("this-month").classList.remove("active");
                document.getElementById("this-day").classList.add("active");
            }

            function thisWeek() {
                document.getElementById("this-month").classList.remove("active");
                document.getElementById("this-day").classList.remove("active");
                document.getElementById("this-week").classList.add("active");
            }

            function thisMonth() {
                document.getElementById("this-week").classList.remove("active");
                document.getElementById("this-day").classList.remove("active");
                document.getElementById("this-month").classList.add("active");
            }
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/livewire/contacts.blade.php ENDPATH**/ ?>