<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="header bg-lighter pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h1 d-inline-block mb-0 mt-4">Dashboard</h6>
                    </div>
                    
                </div>
                <!-- Card stats -->
                <div class="row">
                    <div class="col-xl-3 col-md-6">
                        <div class="card card-stats">
                            <!-- Card body -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Fournisseur</h5>
                                        <span class="h2 font-weight-bold mb-0"><?php echo e($provider->name); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div
                                            class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                                            <i class="fa fa-store"></i>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card card-stats">
                            <!-- Card body -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Package</h5>
                                        <span class="h2 font-weight-bold mb-0"><?php echo e($package->name); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                                            <i class="fa fa-sharp fa-box-open"></i>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card card-stats">
                            <!-- Card body -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Valide Jusqu'au</h5>
                                        <span
                                            class="h2 font-weight-bold mb-0"><?php echo e(Auth::user()->created_at->addYear()->format('d M Y')); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                                            <i class="fa fa-clock"></i>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card card-stats">
                            <!-- Card body -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Max. Profiles</h5>
                                        <span class="h2 font-weight-bold mb-0"><?php echo e(Auth::user()->profile_limit); ?></span>
                                        
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                                            <i class="fa fa-users"></i>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-8">
                <div class="card bg-default">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-light text-uppercase ls-1 mb-1">Courbe D'Activité</h6>
                                <h5 class="h3 text-white mb-0">Contacts Enregistrés</h5>
                            </div>
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Chart -->
                        <div class="chart">
                            <!-- Chart wrapper -->
                            <?php echo $aChart->container(); ?>

                            <?php echo $aChart->script(); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase text-muted ls-1 mb-1">Apport</h6>
                                <h5 class="h3 mb-0">Par Agent</h5>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->master == false): ?>
                                <div class="d-flex align-items-center rounded-pill px-3 py-3 mb-3 bg-lighter">
                                    <div class="media align-items-center">
                                        <a href="<?php echo e(route('nfc.show', $item->id)); ?>" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder"
                                                src="<?php echo e(asset('storage/img/nfc/profile/' . $item->image)); ?>">
                                        </a>
                                        <a href="<?php echo e(route('nfc.show', $item->id)); ?>" class="media-body text-default">
                                            <span class="name mb-0 text-sm font-weight-bold"><?php echo e($item->firstname); ?>

                                                <?php echo e($item->lastname); ?></span>
                                            <small
                                                class="name mb-0 text-xs text-muted d-block"><?php echo e($item->master == true ? 'Directeur Marketinf' : 'Agent Commercial'); ?></small>
                                        </a>

                                    </div>
                                    <div class="ml-auto">
                                        <span class="btn btn-primary rounded-circle h-16"><?php echo e($item->pageviews->count()); ?></span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-8">
                <div class="card">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <h4 class="h3 text-muted mb-0">Activitées Récentes</h4>
                            </div>
                            <div class="col text-right">
                                <a href="/client/activites" class="btn btn-sm btn-info shadow-none">Voir tout</a>
                            </div>
                        </div>
                    </div>
                    <?php if($activities): ?>
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="nfc-profile-item py-2 px-3 my-2 border-bottom shadow--hover">
                                <div class="row">
                                    <div class="col-lg-2">
                                        <div class="media align-items-center">
                                            <div class="media-body">
                                                <span
                                                    class="name mb-0 text-sm font-weight-bold"><?php echo e($activity->created_at->format('D d M')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 media align-items-center">
                                        <small class="mb-0"><?php echo e($activity->country_name); ?>,
                                            <?php echo e($activity->city_name); ?></small>
                                    </div>
                                    <div class="col-lg-4 media align-items-center">
                                        <small class="mb-0 nfc-link-text-2"><?php echo e($activity->user_agent); ?></small>
                                    </div>
                                    <div class="col-lg-4 media align-items-center">
                                        <small class="mb-0"><?php echo e($activity->nfcprofile->firstname); ?>

                                            <?php echo e($activity->nfcprofile->lastname); ?></small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="d-flex align-items-center justify-content-center">
                            <h1 class="muted">Aucune recente activité</h1>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <h4 class="h3 text-muted mb-0">Contacts Récents</h4>
                            </div>
                            <div class="col text-right">
                                <a href="#!" class="btn btn-sm btn-primary shadow-none">Voir tout</a>
                            </div>
                        </div>
                    </div>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="nfc-profile-item py-2 px-3 mx-2 d-flex rounded"
                            <?php if($loop->even): ?> style="background:#eef5fd;" <?php endif; ?>>
                            <div class="row">
                                <div class="col-12">
                                    <div class="media align-items-center">
                                        <div class="media-body">
                                            <span
                                                class="name mb-0 text-sm font-weight-bold"><?php echo e($item->name); ?></span>
                                            <small
                                                class="name mb-0 text-xs text-muted d-block"><?php echo e($item->title); ?></small>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="ml-auto my-auto d-inline">
                                <span class="btn btn-sm badge-success rounded-circle"><a
                                        href="<?php echo e(route('phoneSave', $item->id)); ?>"
                                        class="fa fa-arrow-down text-success"></a></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/dashboard.blade.php ENDPATH**/ ?>