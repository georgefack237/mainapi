<div class="container">

    <div id="profile">
        <!-- Page content -->
        <div class="container-fluid mt-5">
            <div class="row">
                <div class="col-lg-8">
                    <div class="">
                        <!-- Card header -->
                        <div class="row mb-4">
                            <div class="col-lg-6">
                                <h3>Avocats</h3>
                            </div>

                            <div class="col-lg-6 text-right">
                                <a href="#" wire:click="newMail" class="btn btn-sm btn-success mr-2"><i
                                        class="fa fa-plus mr-2"></i>Nouvelle diffusion</a>
                                <a href="#" wire:click="showCreateNfc" class="btn btn-sm btn-success"><i
                                        class="fa fa-plus mr-2"></i>Ajouter</a>
                            </div>
                        </div>

                        <?php if($profiles): ?>
                            <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="nfc-profile-item my-2 shadow-sm px-3 py-2 rounded bg-white"
                                    wire:click="showDemo(<?php echo e($item->id); ?>)">
                                    <div class="row">
                                        <div class="col-7">
                                            <div class="media align-items-center">
                                                <a href="#" class="avatar rounded-circle mr-3">
                                                    <img alt="Image placeholder"
                                                        src="<?php echo e(asset('storage/img/nfc/profile/' . $item->image)); ?>">
                                                </a>
                                                <div class="media-body">
                                                    <span
                                                        class="name mb-0 text-sm font-weight-bold"><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-5 media align-items-center">
                                            <small class="mb-0 nfc-link-text" id="<?php echo e($item->id); ?>">
                                                <?php echo e(route('showlawyer', $item->matricule_key_hash)); ?> </small><i
                                                class="fa fa-clipboard mx-2 copy" id="copy" onclick="toClipboard(this)" data-id="<?php echo e($item->id); ?>"></i>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                </div>

                
                <div class="col-lg-4">

                    

                    <?php if($demo): ?>
                    <div class="bg-white mt-5 p-4 rounded">
                        <h2><?php echo e($demo->first_name); ?> <?php echo e($demo->last_name); ?></h2>
                        <span class="d-block text-green"><small><?php echo e($demo->title); ?></small></span>
                        <span class="d-block text-green"><small><?php echo e($demo->matricule); ?></small></span>
                        <span class="d-block text-green"><small>Date d'inscription: <?php echo e(date("j M Y",  strtotime($demo->created_at))); ?></small></span>
                        <span class="d-block"><?php echo e($demo->address); ?></span>
                        <span class="d-block"><?php echo e($demo->phone); ?></span>
                        <span class="d-block"><?php echo e($demo->Mail); ?></span>
                        <div class="qr mt-3" id="qr">
                            <?php echo QrCode::size(285)->generate(route('showlawyer', $demo->matricule_key_hash)); ?>

                        </div>
                        
                        <button class="btn btn-block btn-success mt-3" onclick="downloadQR()">Télécharger QR</button>
                    </div>
                    <?php else: ?>
                        <div class="d-flex justify-content-center align-items-center h-100 mt-5 px-4 border rounded">
                            <span class="text-center font-weight-bold">Cliquer sur un profil pour afficher le code QR</span>
                        </div>
                    <?php endif; ?>
                    

                </div>
            </div>
        </div>

        <!-- Create profile modal -->

    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['maxWidth' => 'lg','wire:model' => 'createNfcModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => 'lg','wire:model' => 'createNfcModal']); ?>
         <?php $__env->slot('title', null, []); ?> 

         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <form>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Nom</label>
                        <input type="text" class="form-control form-control-muted border-0" wire:model="firstName"
                            id="inputEmail4">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputPassword4">Prenom</label>
                        <input type="text" class="form-control form-control-muted border-0" wire:model="lastName"
                            id="inputPassword4">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputPassword4">Fonction</label>
                        <input type="text" class="form-control form-control-muted border-0" wire:model="title"
                            id="inputPassword4">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Matricule</label>
                        <input type="text" class="form-control form-control-muted border-0" wire:model="matricule"
                            id="inputEmail4">
                    </div>
                </div>

                <hr>

                <div class="form-group">
                    <label for="inputAddress">Address</label>
                    <input type="text" class="form-control form-control-muted border-0" wire:model="address"
                        id="inputAddress">
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Téléphone</label>
                        <input type="phone" class="form-control form-control-muted border-0" wire:model="phone"
                            id="inputEmail4">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Adresse mail</label>
                        <input type="email" class="form-control form-control-muted border-0" wire:model="email"
                            id="inputEmail4">
                    </div>
                </div>

                <div class="input-group mb-3 bg-secondary">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="inputGroupFile01" wire:model="image"
                            aria-describedby="inputGroupFileAddon01">
                        <label class="custom-file-label" for="inputGroupFile01">Cliquer pour choisir une image</label>
                    </div>
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <?php if($image): ?>
                    <div class="w-100 overflow-hidden mb-3">
                        Photo Preview:
                        <img src="<?php echo e($image->temporaryUrl()); ?>" width="40%">
                    </div>
                <?php endif; ?>

                <div class="d-flex align-item-center justify-content-center">
                    <div class="">
                        <button type="button" class="btn btn-success" wire:click="createProfile"
                            wire:loading.attr="disabled">Enregistrer</button>
                        <button type="button" class="btn btn-outline-success" wire:click="$toggle('createNfcModal')"
                            wire:loading.attr="disabled">Annuler</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, ['class' => 'd-none bg-white']); ?> 
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['maxWidth' => 'lg','wire:model' => 'newMailModal']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => 'lg','wire:model' => 'newMailModal']); ?>
         <?php $__env->slot('title', null, []); ?> 
            Nouvelles diffusion
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <form>
                <div class="badge-success py-2 px-3 mb-3 rounded">
                    <p class="text-sm m-0">Ce mail sera envoyé aux <span class="font-weight-bold"><?php echo e($recipients->count()); ?> avocat</span> présent dans votre base de donné</p>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control form-control-muted border-0" placeholder="Sujet" wire:model="subject">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control form-control-muted border-0" placeholder="Titre (optionnel)" wire:model="mailTitle">
                </div>

                <div class="custom-file mb-3">
                    <label class="" for="image">
                        <span type="button" class="btn btn-outline-primary rounded"><i class="bi bi-image mr-2"></i> Ajouter une image</span>
                    </label>
                    <input type="file" wire:model='mail_image' class="custom-file-input d-none" id="image" required>
                </div>

                <div class="form-group">
                    <textarea class="form-control form-control-muted border-0" placeholder="Contenu" wire:model="content" cols="30" rows="10"></textarea>
                </div>

                <div class="d-flex align-item-center justify-content-center">
                    <div class="">
                        <button type="button" class="btn btn-success" wire:click="sendMail"
                            wire:loading.attr="disabled">
                            <i wire:loading.remove wire:target='sendMail' class="fa fa-paper-plane mr-2"></i>
                                <i wire:loading wire:target='sendMail'
                                    class="fa fa-spinner mr-2 animate__animated animate__rotateIn animate__infinite"></i>
                                <span wire:loading.remove wire:target='sendMail'>Envoyer</span>
                                <span wire:loading wire:target='sendMail'>Envoi en cours...</span>
                        </button>
                        
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, ['class' => 'd-none bg-white']); ?> 
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/livewire/lawyers.blade.php ENDPATH**/ ?>