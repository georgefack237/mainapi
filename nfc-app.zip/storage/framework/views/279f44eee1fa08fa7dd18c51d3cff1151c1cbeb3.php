
<div>
    <div class="header py-4 bg-white">
        <div class="container-fluid">
            <div class="header-body">
                <div class="align-items-center mt-4 py-3">
                    <div class="d-flex justify-content-between">
                        <h2 class="mb-4 h1">Notifications</h2>
                        
                    </div>
                    
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid mb-5 mt-3" style="border-radius: 20px;">
        <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="py-2 px-3 mb-2 rounded bg-body shadow-lg--hover">
                <div class="d-flex ali d-lg-block rounded">
                    <div class="row">
                        <div class="col-lg-8">
                            <a class="text-dark" href="#note-<?php echo e($item->id); ?>" data-toggle="collapse"
                                role="button" aria-expanded="false" aria-controls="note-<?php echo e($item->id); ?>">
                                <div class="media align-items-center">
                                    <div class="mr-3 my-auto">
                                        <?php if($item->is_client == false): ?>
                                            <span class="badge badge-lg badge-primary badge-circle">
                                                <i class="<?php echo e($item->icon); ?> text-primary"></i>
                                            </span>
                                        <?php else: ?>
                                            <span class="btn btn-sm badge-info rounded-circle">
                                                <i class="fa fa-check text-info"></i>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm font-weight-bold"><?php echo e($item->title); ?></span>
                                        <small class="name mb-0 text-xs text-muted d-block"><?php echo e($item->description); ?></small>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-4 d-none d-lg-flex align-items-center justify-content-between">
                            <small class="mb-0"><?php echo e($item->profile->firstname); ?> <?php echo e($item->profile->lastname); ?></small>
                            <small class="mb-0 d-block font-weight-500 text-sm"><i class="bi bi-clock mr-2"></i> <?php echo e($item->created_at->format('D d M Y')); ?></small>
                        </div>
                    </div>
                </div>

                
                <div class="collapse mt-1" id="note-<?php echo e($item->id); ?>">
                    <div class="align-items-center d-lg-none text-sm ml-5">
                        <small class="mb-0 mr-2 font-weight-bold d-block">Initié le <?php echo e($item->created_at->format('D d M Y')); ?></small>
                    </div>
                    <div class="text-sm ml-5 d-block d-lg-none">
                        <small class="">Initiateur:</small>
                        <small class=""><?php echo e($item->profile->firstname); ?> <?php echo e($item->profile->lastname); ?></small>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <script>
            function thisDay() {
                document.getElementById("this-week").classList.remove("active");
                document.getElementById("this-month").classList.remove("active");
                document.getElementById("this-day").classList.add("active");
            }

            function thisWeek() {
                document.getElementById("this-month").classList.remove("active");
                document.getElementById("this-day").classList.remove("active");
                document.getElementById("this-week").classList.add("active");
            }

            function thisMonth() {
                document.getElementById("this-week").classList.remove("active");
                document.getElementById("this-day").classList.remove("active");
                document.getElementById("this-month").classList.add("active");
            }
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/livewire/alerts.blade.php ENDPATH**/ ?>