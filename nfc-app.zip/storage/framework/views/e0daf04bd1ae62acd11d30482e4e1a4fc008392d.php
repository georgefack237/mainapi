<div class="py-3">
    <hr />
</div>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>