<div class="navbar-inner">
    <!-- Collapse -->
    <div class="collapse navbar-collapse" id="sidenav-collapse-main">

        <ul class="navbar-nav">
            <?php if(auth()->guard()->check()): ?>
                <div class="card mx-3 bg-transparent shadow-none">
                    <li class="nav-item dropdown mt-4">
                        <a class="pr-0" href="#" role="button" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <div class="d-flex align-items-center text-center border p-2 bg-lighter"
                                style="border-radius: 20px;">
                                <span class="avatar avatar-md rounded-circle">
                                    <img
                                        src="<?php echo e(asset('storage/img/nfc/profile/' . Auth::user()->profile_photo_path)); ?>">
                                </span>
                                <div class="media-body d-none d-lg-block">
                                    <span class="mb-0 text-dark font-weight-bold" style="font-size: 12px;">
                                        <?php echo e(Auth::user()->name); ?>

                                    </span>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-menu  dropdown-menu-right">
                            <div class="dropdown-header noti-title">
                                <h6 class="text-overflow m-0">
                                    <?php echo e(__('Manage Account')); ?>

                                </h6>
                            </div>

                            <a href="<?php echo e(route('profile.show')); ?>" class="dropdown-item">
                                <i class="ni ni-single-02"></i>
                                <span>
                                    <?php echo e(__('Profile')); ?>

                                </span>
                            </a>

                            <?php if(Laravel\Jetstream\Jetstream::hasApiFeatures()): ?>
                                <a href="<?php echo e(route('api-tokens.index')); ?>" class="dropdown-item">
                                    <span>
                                        <?php echo e(__('API Tokens')); ?>

                                    </span>
                                </a>
                            <?php endif; ?>

                            <div class="dropdown-divider"></div>

                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
                                onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <i class="ni ni-user-run"></i>
                                <span>Logout</span>
                            </a>
                            <form method="POST" id="logout-form" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                </div>
            <?php endif; ?>
        </ul>
        <!-- Nav items -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link <?php echo e('dashboard' == request()->path() ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard')); ?>">
                    <i class="ni ni-tv-2 text-success"></i>
                    <span class="nav-link-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e('client/nfcprofiles' == request()->path() ? 'active' : ''); ?>"
                    href="<?php echo e(url('/client/nfcprofiles')); ?>">
                    <i class="bi bi-people-fill text-success"></i>
                    <span class="nav-link-text">Profiles</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('client.contacts') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/client/contacts')); ?>">
                    <i class="bi bi-person-badge text-success"></i>
                    <span class="nav-link-text">Contacts</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('client.appointments') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/client/appointments')); ?>">
                    <i class="bi bi-clipboard-data text-success"></i>
                    <span class="nav-link-text">Agenda</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('client.alerts') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/client/alerts')); ?>">
                    <i class="bi bi-bell text-success"></i>
                    <span class="nav-link-text">Alertes</span>
                    <?php if($alertsCount): ?>
                        <span class="badge badge-pill bg-danger ml-auto"><?php echo e($alertsCount); ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e('client/chats' == request()->path() ? 'active' : ''); ?>"
                    href="<?php echo e(url('/client/chats')); ?>">
                    <i class="bi bi-chat-text text-success"></i>
                    <span class="nav-link-text">Chats</span>
                    <span class="badge badge-pill bg-warning ml-auto">43</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e('client/mailing' == request()->path() ? 'active' : ''); ?>"
                    href="<?php echo e(url('/client/mailing')); ?>">
                    <i class="bi bi-envelope text-success"></i>
                    <span class="nav-link-text">Newsletter</span>
                    
                </a>
            </li>
        </ul>

        
        <ul class="navbar-nav mt-4">
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('client.prospection.*') ? 'active' : ''); ?>"
                    href="#conversion" data-toggle="collapse"
                    role="button" aria-expanded="false" aria-controls="conversion">
                    <i class="bi bi-arrow-left-right"></i>
                    <span class="nav-link-text">Cycle de vente (KPI)</span>
                </a>
            </li>
            
            <div class="collapse mt-1 mb-2 px-5 <?php echo e(request()->routeIs('client.prospection.*') ? 'show' : ''); ?>" id="conversion">
                <ul class="navbar-nav bg-white rounded py-2">
                    
                    <li class="px-2">
                        <a class="nav-link text-xs rounded-lg <?php echo e('client/prospection/leads' == request()->path() ? 'text-primary badge-primary' : 'text-muted'); ?>"
                            href="<?php echo e(url('/client/prospection/leads')); ?>">
                            <i class="bi bi-person-lines-fill"></i>
                            <span class="nav-link-text">Leads</span>
                        </a>
                    </li>
                    <li class="px-2">
                        <a class="nav-link text-xs rounded-lg <?php echo e('client/prospection/prospects' == request()->path() ? 'text-primary badge-primary' : 'text-muted'); ?>"
                            href="<?php echo e(url('/client/prospection/prospects')); ?>">
                            <i class="bi bi-person-lines-fill"></i>
                            <span class="nav-link-text">Prospects</span>
                        </a>
                    </li>
                    <li class="px-2">
                        <a class="nav-link text-xs rounded-lg <?php echo e('client/prospection/opportunities' == request()->path() ? 'text-primary badge-primary' : 'text-muted'); ?>"
                            href="<?php echo e(url('/client/prospection/opportunities')); ?>">
                            <i class="bi bi-person-lines-fill"></i>
                            <span class="nav-link-text">Opportunités</span>
                        </a>
                    </li>
                    <li class="px-2">
                        <a class="nav-link text-xs rounded-lg <?php echo e('client/prospection/clients' == request()->path() ? 'text-primary badge-primary' : 'text-muted'); ?>"
                            href="<?php echo e(url('/client/prospection/clients')); ?>">
                            <i class="bi bi-bag-check-fill"></i>
                            <span class="nav-link-text">Clients</span>
                        </a>
                    </li>
                    
                </ul>
            </div>
        </ul>

        
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('client.market.*') ? 'active' : ''); ?>"
                    href="#market" data-toggle="collapse"
                    role="button" aria-expanded="false" aria-controls="market">
                    <i class="bi bi-bank"></i>
                    <span class="nav-link-text">Chiffre d'affaire</span>
                </a>
            </li>
            
            <div class="collapse mt-1 mb-2 px-5 <?php echo e(request()->routeIs('client.market.*') ? 'show' : ''); ?>" id="market">
                <ul class="navbar-nav bg-white rounded py-2">
                    <li class="px-2">
                        <a class="nav-link text-xs rounded-lg <?php echo e('client/products' == request()->path() ? 'text-primary badge-primary' : 'text-muted'); ?>"
                            href="<?php echo e(url('/client/products')); ?>">
                            <i class="bi bi-basket3"></i>
                            <span class="nav-link-text">Produits</span>
                        </a>
                    </li>
                    <li class="px-2">
                        <a class="nav-link text-xs rounded-lg <?php echo e('client/sales' == request()->path() ? 'text-primary badge-primary' : 'text-muted'); ?>"
                            href="<?php echo e(url('/client/sales')); ?>">
                            <i class="bi bi-cart-check"></i>
                            <span class="nav-link-text">Ventes</span>
                        </a>
                    </li>
                </ul>
            </div>
        </ul>



        
        

        
        
        

    </div>
</div>
<?php /**PATH D:\My Works\Dev\Laravel\nfc-app\resources\views/components/sidenav.blade.php ENDPATH**/ ?>