@extends('layouts.partner')

@section('content')

    <div class="px-5 py-5">
        <h2>Partner Dashboard</h2>
    </div>

@endsection
