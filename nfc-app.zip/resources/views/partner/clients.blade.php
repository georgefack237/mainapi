@extends('layouts.partner')

@section('content')

    <div class="px-5 py-5">
        <h1>Clients</h1>
        @livewire('partner.clients')
    </div>

@endsection
