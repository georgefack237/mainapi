@extends('layouts.profile')

@section('content')

    <div class="px-5 py-5">
        <h2>Agent's Profile Dashboard</h2>
    </div>

@endsection
