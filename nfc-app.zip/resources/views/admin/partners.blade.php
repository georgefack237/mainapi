<x-admin-layout>

    <div class="px-5 py-5">
        <h1>Partenaires</h1>
        @livewire('admin.partners')
    </div>

</x-admin-layout>
