<x-admin-layout>
    <div class="px-5 py-5">
        <h1>Equipe</h1>
        @livewire('admin.commercials')
    </div>
</x-admin-layout>

