<?php

namespace App\Http\Livewire\Layouts;

use Livewire\Component;

class Admin extends Component
{
    public function render()
    {
        return view('livewire.layouts.admin');
    }
}
