<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SaveButtonPressed extends Model
{
    use HasFactory;
    protected $table = 'save_button_pressed';
}
